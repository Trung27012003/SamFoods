import { CommonModule } from "@angular/common";
import { ChangeDetectorRef, Component, computed, inject, OnDestroy, OnInit, signal } from "@angular/core";
import { Router, RouterOutlet, RouterLinkWithHref } from "@angular/router";
import { NzFloatButtonModule } from "ng-zorro-antd/float-button";
import { AvatarModule } from "primeng/avatar";
import { ButtonModule } from "primeng/button";
import { MegaMenuModule } from "primeng/megamenu";
import { NzInputModule, NzInputSearchEvent } from "ng-zorro-antd/input";
import { NzAutocompleteComponent, NzAutocompleteModule } from "ng-zorro-antd/auto-complete";
import { SelectButtonModule } from "primeng/selectbutton";
import { NzDropdownModule } from "ng-zorro-antd/dropdown";
import { NzDrawerModule } from "ng-zorro-antd/drawer";
import { NzIconModule } from "ng-zorro-antd/icon";
import { MegaMenuItem } from "primeng/api";
import { FormsModule } from "@angular/forms";
import { NzCardModule } from "ng-zorro-antd/card";
import { NzBadgeModule } from "ng-zorro-antd/badge";
import { NzDividerModule } from "ng-zorro-antd/divider";
import { ShoppingCart } from "../../pages/shopping/shopping-cart/shopping-cart";
import { CategoryService } from "../../services/category-service";
import { NzNotificationService } from "ng-zorro-antd/notification";
import { CART_PRODUCT_KEY, LOGO_URL, NOTIFICATION_TITLE_MAP, NOTIFICATION_TYPE_MAP, RESPONSE_STATUS, SOCIALS } from "../../shared/common.config";
import { ProductService } from "../../services/product-service";
import { HistorySearchService } from "../../services/history-search-service";
import { AuthService } from "../auth-layout/auth-service";

@Component({
	selector: 'app-shopping-layout',
	imports: [
		CommonModule,
		FormsModule,
		RouterOutlet,
		AvatarModule,
		ButtonModule,
		MegaMenuModule,
		SelectButtonModule,
		NzDropdownModule,
		NzDrawerModule,
		NzIconModule,
		NzInputModule,
		NzAutocompleteModule,
		NzFloatButtonModule,
		NzCardModule,
		NzBadgeModule,
		NzDividerModule,
		ShoppingCart,
		RouterLinkWithHref
	],
	templateUrl: './shopping-layout.html',
	styleUrl: './shopping-layout.css',
	// template: '',
	standalone: true,
	providers: [
		CategoryService,
		ProductService,
		HistorySearchService
	]
})
export class ShoppingLayout implements OnInit, OnDestroy {

	private productService = inject(ProductService);
	private categoryService = inject(CategoryService);
	private historySearchService = inject(HistorySearchService);
	private notification = inject(NzNotificationService);
	private cdr = inject(ChangeDetectorRef);
	private router = inject(Router);
	private authService = inject(AuthService);

	get isLoggedIn(): boolean {
		return this.authService.isLoggedIn();
	}

	get currentUser() {
		return this.authService.getCurrentUser();
	}

	get isAdmin(): boolean {
		return this.authService.isAdmin();
	}

	logout(): void {
		this.authService.logout();
		this.router.navigate(['/login']);
	}
	megaMenuItems: MegaMenuItem[] | undefined;
	responsiveOptions: any[] | undefined;
	products: any[] = [];
	productNews: any[] = [];
	productBestSellers: any[] = [];

	options: any[] = ['list', 'grid'];
	layout = this.options[0];
	keyword = '';

	// autoCompleteKeywords = [
	// 	{ label: 'Lucy', value: 'lucy' },
	// 	{ label: 'Jack', value: 'jack' }
	// ];

	autoCompleteKeywords: string[] = [];
	optionKeywordss = ['Burns Bay Road', 'Downing Street', 'Wall Street'];

	isVisibleShopingCard = false;
	isMobileMenuOpen = false;

	toggleMobileMenu(): void {
		this.isMobileMenuOpen = !this.isMobileMenuOpen;
	}

	closeMobileMenu(): void {
		this.isMobileMenuOpen = false;
	}
	// shopingCarts: any[] = [];
	totalQuantity = computed(() =>
		this.productService.carts().reduce((sum, item) => sum + item.Quantity, 0)
	);

	isOnCartPage(): boolean {
		return this.router.url.includes('/cart');
	}

	logoURL = LOGO_URL;
	socials = SOCIALS;

	aboutLinks = [
		{ label: 'Giới thiệu', link: '/home' },
		{ label: 'Tầm nhìn & Sứ mệnh', link: '/home' },
		{ label: 'Đội ngũ của chúng tôi', link: '/home' },
		{ label: 'Tuyển dụng', link: '/home' },
		{ label: 'Tin tức & Sự kiện', link: '/home' }
	];

	supportLinks = [
		{ label: 'Hướng dẫn đặt hàng', link: '/home' },
		{ label: 'Câu hỏi thường gặp', link: '/home' },
		{ label: 'Liên hệ hỗ trợ', link: '/home' },
		{ label: 'Đăng ký đối tác', link: '/home' },
		{ label: 'Đánh giá dịch vụ', link: '/home' }
	];

	policyLinks = [
		{ label: 'Chính sách đổi trả', link: '/home' },
		{ label: 'Chính sách hoàn tiền', link: '/home' },
		{ label: 'Chính sách vận chuyển', link: '/home' },
		{ label: 'Chính sách bảo mật', link: '/home' },
		{ label: 'Điều khoản sử dụng', link: '/home' }
	];

	constructor() {
		this.loadHistorySearch();

	}

	ngOnInit(): void {
		// this.loadHistorySearch();
		this.initMenuItems();
		this.loadShoppingCards();

		window.addEventListener('storage', this.onStorageChange);
		window.addEventListener('cartUpdated', this.onCartUpdated);
	}

	ngOnDestroy(): void {
		window.removeEventListener('storage', this.onStorageChange);
		window.removeEventListener('cartUpdated', this.onCartUpdated);
	}

	private onStorageChange = (e: StorageEvent) => {
		if (e.key === CART_PRODUCT_KEY) this.loadShoppingCards();
	};

	private onCartUpdated = () => this.loadShoppingCards();

	initMenuItems() {
		this.megaMenuItems = [
			{
				label: 'Hàng mới',
				command: () => {
					this.router.navigate(['/home']);
				}
			},
			{
				label: 'Tất cả sản phẩm',
				command: () => {
					this.router.navigate(['/products']);
				}
			},
			{
				label: 'Bán chạy',
			},
			// {
			// 	label: 'Sports',
			// 	// icon: 'pi pi-clock',
			// 	items: [
			// 		[
			// 			{
			// 				label: 'Football',
			// 				items: [{ label: 'Kits' }, { label: 'Shoes' }, { label: 'Shorts' }, { label: 'Training' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Running',
			// 				items: [{ label: 'Accessories' }, { label: 'Shoes' }, { label: 'T-Shirts' }, { label: 'Shorts' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Swimming',
			// 				items: [{ label: 'Kickboard' }, { label: 'Nose Clip' }, { label: 'Swimsuits' }, { label: 'Paddles' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Tennis',
			// 				items: [{ label: 'Balls' }, { label: 'Rackets' }, { label: 'Shoes' }, { label: 'Training' }]
			// 			}
			// 		]
			// 	]
			// },
			// {
			// 	label: 'Sports',
			// 	// icon: 'pi pi-clock',
			// 	items: [
			// 		[
			// 			{
			// 				label: 'Football',
			// 				items: [{ label: 'Kits' }, { label: 'Shoes' }, { label: 'Shorts' }, { label: 'Training' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Running',
			// 				items: [{ label: 'Accessories' }, { label: 'Shoes' }, { label: 'T-Shirts' }, { label: 'Shorts' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Swimming',
			// 				items: [{ label: 'Kickboard' }, { label: 'Nose Clip' }, { label: 'Swimsuits' }, { label: 'Paddles' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Tennis',
			// 				items: [{ label: 'Balls' }, { label: 'Rackets' }, { label: 'Shoes' }, { label: 'Training' }]
			// 			}
			// 		]
			// 	]
			// },
			// {
			// 	label: 'Sports',
			// 	icon: 'pi pi-clock',
			// 	items: [
			// 		[
			// 			{
			// 				label: 'Football',
			// 				items: [{ label: 'Kits' }, { label: 'Shoes' }, { label: 'Shorts' }, { label: 'Training' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Running',
			// 				items: [{ label: 'Accessories' }, { label: 'Shoes' }, { label: 'T-Shirts' }, { label: 'Shorts' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Swimming',
			// 				items: [{ label: 'Kickboard' }, { label: 'Nose Clip' }, { label: 'Swimsuits' }, { label: 'Paddles' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Tennis',
			// 				items: [{ label: 'Balls' }, { label: 'Rackets' }, { label: 'Shoes' }, { label: 'Training' }]
			// 			}
			// 		]
			// 	]
			// },
			// {
			// 	label: 'Sports',
			// 	icon: 'pi pi-clock',
			// 	items: [
			// 		[
			// 			{
			// 				label: 'Football',
			// 				items: [{ label: 'Kits' }, { label: 'Shoes' }, { label: 'Shorts' }, { label: 'Training' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Running',
			// 				items: [{ label: 'Accessories' }, { label: 'Shoes' }, { label: 'T-Shirts' }, { label: 'Shorts' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Swimming',
			// 				items: [{ label: 'Kickboard' }, { label: 'Nose Clip' }, { label: 'Swimsuits' }, { label: 'Paddles' }]
			// 			}
			// 		],
			// 		[
			// 			{
			// 				label: 'Tennis',
			// 				items: [{ label: 'Balls' }, { label: 'Rackets' }, { label: 'Shoes' }, { label: 'Training' }]
			// 			}
			// 		]
			// 	]
			// }
		];

		this.categoryService.getData().subscribe({
			next: (res) => {
				const categoryRoot = res.data.filter((x: any) => x.ParentID === 0 && x.IsDeleted === 0);
				this.megaMenuItems?.push(
					{
						label: 'Sports',
						// icon: 'pi pi-clock',
						items: [
							[
								{
									label: 'Football',
									items: [{ label: 'Kits' }, { label: 'Shoes' }, { label: 'Shorts' }, { label: 'Training' }]
								}
							],
							[
								{
									label: 'Running',
									items: [{ label: 'Accessories' }, { label: 'Shoes' }, { label: 'T-Shirts' }, { label: 'Shorts' }]
								}
							],
							[
								{
									label: 'Swimming',
									items: [{ label: 'Kickboard' }, { label: 'Nose Clip' }, { label: 'Swimsuits' }, { label: 'Paddles' }]
								}
							],
							[
								{
									label: 'Tennis',
									items: [{ label: 'Balls' }, { label: 'Rackets' }, { label: 'Shoes' }, { label: 'Training' }]
								}
							]
						]
					},
				)

				this.cdr.detectChanges();
			},
			error: (err) => {
				this.notification.create(
					NOTIFICATION_TYPE_MAP[err.status] || 'error',
					NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
					err?.error?.message || `${err.error}\n${err.message}`,
					{
						nzStyle: { whiteSpace: 'pre-line' }
					}
				);
			}
		})
	}

	loadShoppingCards() {
		const cartValue = localStorage.getItem(CART_PRODUCT_KEY);
		const carts = cartValue ? JSON.parse(cartValue) : [];
		this.productService.setCarts(carts);
		this.cdr.detectChanges();
	}

	loadHistorySearch() {
		this.historySearchService.getData().subscribe({
			next: (res) => {
				console.log('res.data:', res.data);
				// this.notification.success(NOTIFICATION_TITLE_MAP[res.status as RESPONSE_STATUS], res.message);
				// this.modal.close(this.validateForm.value);

				this.optionKeywordss = res.data.map((item: any) => item.Keyword);
				this.autoCompleteKeywords = this.optionKeywordss;
				this.cdr.detectChanges();
			},
			error: (err) => {
				// this.loading.set(false);
				this.notification.create(
					NOTIFICATION_TYPE_MAP[err.status] || 'error',
					NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
					err?.error?.message || `${err.error}\n${err.message}`,
					{
						nzStyle: { whiteSpace: 'pre-line' }
					}
				);
			}
		})
	}

	onCloseShoppingCard(event?: Event) {
		event?.stopPropagation();
		event?.preventDefault();
		this.isVisibleShopingCard = false;
	}

	onChange(value: string): void {
		this.autoCompleteKeywords = this.optionKeywordss.filter(option => option.toLowerCase().indexOf(value.toLowerCase()) !== -1);
	}

	onSearch(event: NzInputSearchEvent): void {

		const keyword = (event.value || '').trim();
		if (!keyword) return;

		const data = {
			ID: 0,
			Keyword: keyword
		};

		this.historySearchService.saveData(data).subscribe({
			next: (res) => {
				console.log('res.data:', res.data);
				this.loadHistorySearch();
				this.router.navigate(['/products'], { queryParams: { keyword } });
			},
			error: (err) => {
				// Vẫn navigate dù lỗi lưu lịch sử
				this.router.navigate(['/products'], { queryParams: { keyword } });
				this.notification.create(
					NOTIFICATION_TYPE_MAP[err.status] || 'error',
					NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
					err?.error?.message || `${err.error}\n${err.message}`,
					{
						nzStyle: { whiteSpace: 'pre-line' }
					}
				);
			}
		})
	}
}
