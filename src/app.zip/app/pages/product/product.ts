import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { Menubar } from 'primeng/menubar';
import { TableModule } from 'primeng/table';
import { MenuItem } from 'primeng/api';

import { ProductService } from '../../services/product-service';
import { CategoryService } from '../../services/category-service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { ColumnTable } from '../../models/column-table';
import { ProductDetail } from './product-detail/product-detail';
import { NOTIFICATION_TITLE_MAP, NOTIFICATION_TYPE_MAP, RESPONSE_STATUS } from '../../shared/common.config';

interface StatusOption {
	label: string;
	value: number;
}

@Component({
	selector: 'app-product',
	imports: [
		CommonModule,
		FormsModule,
		Menubar,
		TableModule,
		NzIconModule,
		NzButtonModule,
		NzSelectModule,
		NzTagModule,
		NzEmptyModule
	],
	templateUrl: './product.html',
	styleUrl: './product.css',
	standalone: true,
	providers: [ProductService, CategoryService, NzModalService, NzNotificationService]
})
export class Product implements OnInit {
	private productService = inject(ProductService);
	private categoryService = inject(CategoryService);
	private modal = inject(NzModalService);
	private notification = inject(NzNotificationService);
	private cdr = inject(ChangeDetectorRef);

	menuBars: MenuItem[] = [];
	products: any[] = [];
	productsRaw: any[] = [];
	categories: any[] = [];

	isLoadingData = signal(false);
	isLoadingModal = signal(false);

	selectedItem: any = {};
	selectedItemRaw: any = {};
	searchValue = signal('');
	selectedCategory = signal<number | null>(null);
	selectedStatus = signal<number | null>(null);

	statusOptions: StatusOption[] = [
		{ label: 'Còn hàng', value: 1 },
		{ label: 'Hết hàng', value: 2 },
		{ label: 'Hàng mới', value: 3 }
	];

	cols: ColumnTable[] = [
		{ field: 'ProductCode', header: 'Mã SP' },
		{ field: 'ProductName', header: 'Tên sản phẩm' },
		{ field: 'CategoryName', header: 'Danh mục' },
		{ field: 'UnitPrice', header: 'Đơn giá' },
		{ field: 'UnitName', header: 'ĐVT' },
		{ field: 'StatusName', header: 'Tình trạng' }
	];

	ngOnInit(): void {
		this.initMenuBar();
		this.loadCategories();
		this.loadData();
	}

	initMenuBar(): void {
		this.menuBars = [
			{
				label: 'Thêm',
				icon: 'fa-solid fa-circle-plus fa-lg text-success',
				command: () => this.onCreate()
			},
			{
				label: 'Sửa',
				icon: 'fa-solid fa-file-pen fa-lg text-primary',
				command: () => this.onEdit()
			},
			{
				label: 'Xóa',
				icon: 'fa-solid fa-trash fa-lg text-danger',
				command: () => this.onDelete()
			}
		];
	}

	loadCategories(): void {
		this.categoryService.getData().subscribe({
			next: (res) => {
				this.categories = res.data;
			},
			error: (err) => {
				this.notification.create(
					NOTIFICATION_TYPE_MAP[err.status] || 'error',
					NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
					err?.error?.message || err.message
				);
			}
		});
	}

	loadData(): void {
		this.isLoadingData.set(true);
		this.productService.getData().subscribe({
			next: (res) => {
				this.productsRaw = res.data;
				this.products = this.productsRaw.map((item: any) => ({
					...item,
					StatusName: this.getStatusName(item.Status),
					UnitPrice: this.formatCurrency(item.UnitPrice)
				}));
				this.applyFilters();
				this.isLoadingData.set(false);
			},
			error: (err) => {
				this.isLoadingData.set(false);
				this.notification.create(
					NOTIFICATION_TYPE_MAP[err.status] || 'error',
					NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
					err?.error?.message || err.message,
					{ nzStyle: { whiteSpace: 'pre-line' } }
				);
			}
		});
	}

	getStatusName(status: number): string {
		const statusMap: Record<number, string> = {
			1: 'Còn hàng',
			2: 'Hết hàng',
			3: 'Hàng mới'
		};
		return statusMap[status] || 'Không xác định';
	}

	getStatusColor(status: number): string {
		const colorMap: Record<number, string> = {
			1: 'success',
			2: 'error',
			3: 'processing'
		};
		return colorMap[status] || 'default';
	}

	formatCurrency(value: number): string {
		if (!value) return '0 ₫';
		return new Intl.NumberFormat('vi-VN', {
			style: 'currency',
			currency: 'VND'
		}).format(value);
	}

	applyFilters(): void {
		const search = this.searchValue().toLowerCase().trim();
		const categoryId = this.selectedCategory();
		const status = this.selectedStatus();

		const filtered = this.productsRaw.filter(item => {
			const matchSearch = !search ||
				item.ProductName?.toLowerCase().includes(search) ||
				item.ProductCode?.toLowerCase().includes(search);
			const matchCategory = !categoryId || item.CategoryID === categoryId;
			const matchStatus = !status || item.Status === status;

			return matchSearch && matchCategory && matchStatus;
		});

		this.products = filtered.map((item: any) => ({
			...item,
			StatusName: this.getStatusName(item.Status),
			UnitPrice: this.formatCurrency(item.UnitPrice)
		}));
	}

	onSearch(value: string): void {
		this.searchValue.set(value);
		this.applyFilters();
	}

	onCategoryChange(value: number | null): void {
		this.selectedCategory.set(value);
		this.applyFilters();
	}

	onStatusChange(value: number | null): void {
		this.selectedStatus.set(value);
		this.applyFilters();
	}

	onRowSelect(event: any): void {
		const selectedId = event.data?.ID;
		if (selectedId) {
			this.selectedItemRaw = this.productsRaw.find(p => p.ID === selectedId) || event.data;
		}
	}

	onRowUnselect(event: any): void {
		this.selectedItemRaw = {};
	}

	clearFilters(): void {
		this.searchValue.set('');
		this.selectedCategory.set(null);
		this.selectedStatus.set(null);
		this.applyFilters();
	}

	openModal(data: any | null, isEdit: boolean): void {
		const modalRef = this.modal.create({
			nzTitle: isEdit ? 'Sửa sản phẩm' : 'Thêm sản phẩm',
			nzContent: ProductDetail,
			nzWidth: '80vw',
			nzStyle: { top: '20px' },
			nzBodyStyle: { height: '85vh', overflow: 'auto' },
			nzFooter: [
				{ label: 'Hủy', onClick: () => modalRef.close() },
				{
					label: 'Lưu',
					type: 'primary',
					loading: () => this.isLoadingModal(),
					onClick: (componentInstance: any) => {
						if (componentInstance?.isLoading?.()) {
							return;
						}
						componentInstance?.handleOk();
					}
				}
			],
			nzData: { product: data }
		});

		modalRef.afterClose.subscribe(result => {
			if (result) {
				this.loadData();
			}
			this.isLoadingModal.set(false);
		});
	}

	onCreate(): void {
		this.openModal(null, false);
	}

	onEdit(): void {
		if (!this.selectedItem?.ID) {
			this.notification.warning('Thông báo', 'Vui lòng chọn một sản phẩm để sửa!');
			return;
		}
		this.openModal(this.selectedItemRaw, true);
	}

	onDelete(): void {
		if (!this.selectedItem?.ID) {
			this.notification.warning('Thông báo', 'Vui lòng chọn một sản phẩm để xóa!');
			return;
		}

		this.modal.confirm({
			nzTitle: 'Xác nhận xóa',
			nzContent: `<b style="color: red;">
				Bạn có chắc muốn xóa sản phẩm
				<span class="text-primary">${this.selectedItem.ProductName}</span> không?
			</b>`,
			nzOkText: 'Xóa',
			nzOkType: 'primary',
			nzOkDanger: true,
			nzOnOk: () => {
				const data = { ID: this.selectedItem.ID, IsDeleted: true };
				this.productService.saveData(data).subscribe({
					next: (res) => {
						this.loadData();
						this.notification.success(
							NOTIFICATION_TITLE_MAP[res.status as RESPONSE_STATUS],
							res.message
						);
					},
					error: (err) => {
						this.notification.create(
							NOTIFICATION_TYPE_MAP[err.status] || 'error',
							NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
							err?.error?.message || err.message,
							{ nzStyle: { whiteSpace: 'pre-line' } }
						);
					}
				});
			},
			nzCancelText: 'Hủy'
		});
	}
}
