import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { Menubar } from 'primeng/menubar';
import { TableModule } from 'primeng/table';
import { MenuItem } from 'primeng/api';

import { InvoiceService } from '../../services/invoice-service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { ColumnTable } from '../../models/column-table';
import { InvoiceDetail } from './invoice-detail/invoice-detail';
import {
	NOTIFICATION_TITLE_MAP,
	NOTIFICATION_TYPE_MAP,
	RESPONSE_STATUS,
	formatCurrency,
	formatDateTime
} from '../../shared/common.config';

interface StatusOption {
	label: string;
	value: number;
	color: string;
}

@Component({
	selector: 'app-invoice',
	imports: [
		CommonModule,
		FormsModule,
		Menubar,
		TableModule,
		NzIconModule,
		NzButtonModule,
		NzSelectModule,
		NzTagModule,
		NzEmptyModule
	],
	templateUrl: './invoice.html',
	styleUrl: './invoice.css',
	standalone: true,
	providers: [InvoiceService, NzModalService, NzNotificationService]
})
export class Invoice implements OnInit {
	private invoiceService = inject(InvoiceService);
	private modal = inject(NzModalService);
	private notification = inject(NzNotificationService);
	private cdr = inject(ChangeDetectorRef);

	menuBars: MenuItem[] = [];
	invoices: any[] = [];
	invoicesRaw: any[] = [];

	isLoadingData = signal(false);
	isLoadingModal = signal(false);

	selectedItem: any = {};
	selectedItemRaw: any = {};
	searchValue = signal('');
	selectedStatus = signal<number | null>(null);

	statusOptions: StatusOption[] = [
		{ label: 'Mới', value: 0, color: 'processing' },
		{ label: 'Đang giao', value: 2, color: 'warning' },
		{ label: 'Hoàn thành', value: 3, color: 'success' }
	];

	cols: ColumnTable[] = [
		{ field: 'BillCode', header: 'Mã đơn' },
		{ field: 'CustomerName', header: 'Khách hàng' },
		{ field: 'PhoneNumber', header: 'SĐT' },
		{ field: 'Address', header: 'Địa chỉ' },
		{ field: 'TotalAmountText', header: 'Tổng tiền' },
		{ field: 'StatusName', header: 'Trạng thái' },
		{ field: 'BillDateText', header: 'Ngày đặt' }
	];

	ngOnInit(): void {
		this.initMenuBar();
		this.loadData();
	}

	initMenuBar(): void {
		this.menuBars = [
			{
				label: 'Xem chi tiết',
				icon: 'fa-solid fa-eye fa-lg text-info',
				command: () => this.onViewDetail()
			},
			{
				label: 'Sửa',
				icon: 'fa-solid fa-file-pen fa-lg text-primary',
				command: () => this.onEdit()
			},
			{
				label: 'Xóa',
				icon: 'fa-solid fa-trash fa-lg text-danger',
				command: () => this.onDelete()
			}
		];
	}

	loadData(): void {
		this.isLoadingData.set(true);
		this.invoiceService.getData().subscribe({
			next: (res) => {
				this.invoicesRaw = (res.data || []).map((item: any) => ({
					...item,
					StatusName: this.getStatusName(item.Status),
					TotalAmountText: formatCurrency(item.TotalAmount),
					BillDateText: formatDateTime(item.BillDate)
				}));
				this.applyFilters();
				this.isLoadingData.set(false);
			},
			error: (err) => {
				this.isLoadingData.set(false);
				this.notification.create(
					NOTIFICATION_TYPE_MAP[err.status] || 'error',
					NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
					err?.error?.message || err.message,
					{ nzStyle: { whiteSpace: 'pre-line' } }
				);
			}
		});
	}

	getStatusName(status: number): string {
		const found = this.statusOptions.find(s => s.value === status);
		return found ? found.label : 'Không xác định';
	}

	getStatusColor(status: number): string {
		const found = this.statusOptions.find(s => s.value === status);
		return found ? found.color : 'default';
	}

	applyFilters(): void {
		const search = this.searchValue().toLowerCase().trim();
		const status = this.selectedStatus();

		const filtered = this.invoicesRaw.filter(item => {
			const matchSearch = !search ||
				item.BillCode?.toLowerCase().includes(search) ||
				item.CustomerName?.toLowerCase().includes(search) ||
				item.PhoneNumber?.toLowerCase().includes(search);
			const matchStatus = status === null || item.Status === status;
			return matchSearch && matchStatus;
		});

		this.invoices = filtered.map((item: any) => ({
			...item,
			StatusName: this.getStatusName(item.Status),
			TotalAmountText: formatCurrency(item.TotalAmount),
			BillDateText: formatDateTime(item.BillDate)
		}));
	}

	onSearch(value: string): void {
		this.searchValue.set(value);
		this.applyFilters();
	}

	onStatusChange(value: number | null): void {
		this.selectedStatus.set(value);
		this.applyFilters();
	}

	clearFilters(): void {
		this.searchValue.set('');
		this.selectedStatus.set(null);
		this.applyFilters();
	}

	onRowSelect(event: any): void {
		const selectedId = event.data?.ID;
		if (selectedId) {
			this.selectedItemRaw = this.invoicesRaw.find(i => i.ID === selectedId) || event.data;
		}
	}

	onRowUnselect(event: any): void {
		this.selectedItemRaw = {};
	}

	openModal(data: any, mode: 'view' | 'edit'): void {
		const invoiceId = data?.ID;
		if (!invoiceId) {
			this.notification.warning('Thông báo', 'Không tìm thấy mã đơn hàng hợp lệ!');
			return;
		}

		this.isLoadingModal.set(true);
		this.invoiceService.getByID(invoiceId).subscribe({
			next: (res) => {
				const payload = res?.data ?? {};
				// Backend GET /api/invoice/{id} trả { invoice, details }
				const invoiceDetail = payload.invoice ?? payload;
				const detailItems = payload.details ?? invoiceDetail?.InvoiceDetails ?? [];
				const merged = { ...invoiceDetail, InvoiceDetails: detailItems };
				this.showModal(merged, mode);
			},
			error: (err) => {
				// Fallback: dùng data từ list nếu API detail lỗi
				this.showModal(data, mode);
				this.notification.create(
					NOTIFICATION_TYPE_MAP[err.status] || 'warning',
					NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Cảnh báo',
					`Không tải được chi tiết đơn hàng (${err?.error?.message || err.message}). Hiển thị dữ liệu tạm.`,
					{ nzStyle: { whiteSpace: 'pre-line' } }
				);
			}
		});
	}

	private showModal(invoiceData: any, mode: 'view' | 'edit'): void {
		const modalRef: any = this.modal.create({
			nzTitle: mode === 'view' ? 'Chi tiết đơn hàng' : 'Sửa đơn hàng',
			nzContent: InvoiceDetail,
			nzWidth: 800,
			nzStyle: { top: '20px' },
			nzBodyStyle: { maxHeight: '85vh', overflow: 'auto' },
			nzFooter: mode === 'view'
				? [
					{
						label: 'Đóng',
						onClick: (): void => modalRef.close()
					}
				]
				: [
					{
						label: 'Hủy',
						onClick: (): void => modalRef.close()
					},
					{
						label: 'Lưu',
						type: 'primary',
						loading: (componentInstance?: any): boolean => !!componentInstance?.isLoading?.(),
						onClick: (componentInstance?: any): void => {
							if (componentInstance?.isLoading?.()) return;
							componentInstance?.handleOk();
						}
					}
				],
			nzData: { invoice: invoiceData, mode }
		});

		modalRef.afterClose.subscribe((result: any) => {
			if (result) this.loadData();
			this.isLoadingModal.set(false);
		});
	}

	onViewDetail(): void {
		const item = this.selectedItemRaw?.ID ? this.selectedItemRaw : this.selectedItem;
		if (!item?.ID) {
			this.notification.warning('Thông báo', 'Vui lòng chọn một đơn hàng để xem chi tiết!');
			return;
		}
		this.openModal(item, 'view');
	}

	onEdit(): void {
		const item = this.selectedItemRaw?.ID ? this.selectedItemRaw : this.selectedItem;
		if (!item?.ID) {
			this.notification.warning('Thông báo', 'Vui lòng chọn một đơn hàng để sửa!');
			return;
		}
		this.openModal(item, 'edit');
	}

	onDelete(): void {
		const item = this.selectedItemRaw?.ID ? this.selectedItemRaw : this.selectedItem;
		if (!item?.ID) {
			this.notification.warning('Thông báo', 'Vui lòng chọn một đơn hàng để xóa!');
			return;
		}

		const target = item;
		this.modal.confirm({
			nzTitle: 'Xác nhận xóa',
			nzContent: `<b style="color: red;">
				Bạn có chắc muốn xóa đơn hàng
				<span class="text-primary">${target.BillCode || target.ID}</span> không?
			</b>`,
			nzOkText: 'Xóa',
			nzOkType: 'primary',
			nzOkDanger: true,
			nzOnOk: () => {
				this.invoiceService.softDelete(target.ID).subscribe({
					next: (res) => {
						this.loadData();
						this.selectedItem = {};
						this.selectedItemRaw = {};
						this.notification.success(
							NOTIFICATION_TITLE_MAP[res.status as RESPONSE_STATUS],
							res.message
						);
					},
					error: (err) => {
						this.notification.create(
							NOTIFICATION_TYPE_MAP[err.status] || 'error',
							NOTIFICATION_TITLE_MAP[err.status as RESPONSE_STATUS] || 'Lỗi',
							err?.error?.message || err.message,
							{ nzStyle: { whiteSpace: 'pre-line' } }
						);
					}
				});
			},
			nzCancelText: 'Hủy'
		});
	}
}
